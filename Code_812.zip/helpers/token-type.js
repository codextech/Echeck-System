


// enum
const TokenType = {
    emailVerify: 'email verify',
    checkRecieve: 'check recieve',
    sndPartnerSign: 'sender partner sign',
    recPartnerSign: 'reciever partner sign'
}
module.exports = {
    TokenType
  }