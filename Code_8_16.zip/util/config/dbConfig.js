
const config = {
  "development": {

      "host":"localhost",
      "database": "echequedb",
      "user" : "root",
      "password": "tanzeel10"
  },

  "production":{
    "host":"ftp.youseva.com",
    "user":"yousevac_echeck",
    "password":"Echeck9477#",
    "database":"yousevac_echeck"
}

}
module.exports = config;
